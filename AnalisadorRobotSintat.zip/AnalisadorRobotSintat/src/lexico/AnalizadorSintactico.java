// src/sintactico/AnalizadorSintactico.java
package lexico;

import lexico.Lexer;       // Importa el lexer generado por JFlex
import lexico.Yytoken;     // Importa la clase de token (Yytoken)
import lexico.TokenTypes;  // Importa la interfaz de tipos de token

import java.util.List;    // Para recibir la lista de líneas de código
import java.util.ArrayList; // No usado directamente en este parser, pero útil para listas si se necesitara
import java.io.IOException; // Necesario porque lexer.yylex() puede lanzar IOException

// --- Importaciones para la Tabla de Símbolos ---
import java.util.HashSet; // Usaremos HashSet para la tabla de símbolos de robots
import java.util.Set;     // Usaremos Set como tipo general

// Clase que implementa el analizador sintáctico manual (parser) por descenso recursivo,
// incluyendo verificaciones semánticas básicas (como la declaración de robots).
public class AnalizadorSintactico {

    private Lexer lexer; // Referencia a la instancia del lexer que provee los tokens
    private Yytoken lookahead; // El token actual (el siguiente a procesar). Siempre un Yytoken.
    private List<String> lineasCodigo; // Las líneas de código originales (para reportar errores precisos por línea)
    private StringBuilder errores; // Acumula todos los mensajes de error (léxicos reportados por parser, sintácticos, semánticos)

    // --- Tabla de Símbolos Simple ---
    private Set<String> declaredRobots; // Conjunto para almacenar los nombres String de los robots declarados.


    // Constructor: Inicializa el parser con el lexer y las líneas de código fuente.
    public AnalizadorSintactico(Lexer lexer, List<String> lineasCodigo) {
        this.lexer = lexer;
        this.lineasCodigo = lineasCodigo;
        this.errores = new StringBuilder();
        this.lookahead = null; // Se inicializará con el primer token en analizar()

        // --- Inicializar la Tabla de Símbolos ---
        // Se crea una nueva instancia vacía cada vez que se crea un AnalizadorSintactico.
        this.declaredRobots = new HashSet<>();
    }

    // Método principal para iniciar el proceso de análisis.
    // Llama a la regla de inicio de la gramática (parseProgram) y gestiona errores de alto nivel.
    // Retorna un String con el resultado ("CORRECTO" o la lista de errores).
    public String analizar() {
        errores.setLength(0); // Limpiar errores de análisis anteriores

        // --- Reinicializar la Tabla de Símbolos para cada análisis ---
        // Es crucial que la tabla de símbolos esté limpia al inicio de cada nuevo análisis
        // del código fuente completo.
        this.declaredRobots.clear();

        try {
            // Obtener el primer token del lexer para inicializar el 'lookahead'.
            nextToken(); // Lee el primer Yytoken.

            // Llamar al método que parsea la regla de inicio de la gramática ('Program').
            parseProgram();

            // Después de parsear todo el 'Program', el lookahead debe ser EOF.
            // Si no lo es, significa que quedó texto extra o inesperado al final.
            if (lookahead.tipo != TokenTypes.EOF) {
                 // Reporta como error sintáctico (false).
                 reportError("Texto inesperado al final del archivo. Posiblemente falte un ';'.", lookahead, false);
            }

        } catch (IOException e) {
            // Capturar errores de lectura que pueda lanzar el lexer (raro con StringReader).
            errores.append("Error de lectura durante el análisis léxico/sintáctico: ").append(e.getMessage()).append("\n");
            e.printStackTrace(); // Para depuración.
        } catch (Exception e) {
            // Capturar otras excepciones inesperadas o lanzadas intencionalmente por los métodos de parseo.
            errores.append("Error interno o irrecuperable del analizador: ").append(e.getMessage()).append("\n");
            e.printStackTrace(); // Para depuración.
        }

        // Devuelve los errores acumulados. Si no se reportó ninguno, devuelve mensaje de éxito.
        if (errores.length() == 0) {
             return "Análisis sintáctico exitoso.\n"; // Mensaje de éxito si no hubo errores.
        } else {
             return "Análisis con ERRORES encontrados:\n" + errores.toString(); // Devuelve la lista de errores.
        }
    }

    // ---- Métodos Auxiliares Fundamentales para el Parser ----

    // Lee el siguiente token del lexer y lo asigna a 'lookahead'.
    // Es la única forma de avanzar en el flujo de tokens de entrada.
    private void nextToken() throws IOException {
        // Llama al método generado por JFlex para obtener el siguiente token (que es un Yytoken).
        Yytoken next = lexer.yylex();

        // Manejo del final del archivo (EOF).
        // Si yylex() devuelve null o un token <<EOF>>, asegúrate de que 'lookahead' sea un Yytoken EOF.
        if (next == null) {
             // Si ya estábamos en EOF, no hacer nada más.
             if (this.lookahead != null && this.lookahead.tipo == TokenTypes.EOF) {
                 return;
             }
             // Si llega null y no estábamos en EOF, crea un token EOF manual. Estima su posición.
             int lastLine = lineasCodigo.size() > 0 ? lineasCodigo.size() - 1 : 0;
             int lastCol = lineasCodigo.size() > 0 ? lineasCodigo.get(lastLine).length() : 0;
             this.lookahead = new Yytoken(TokenTypes.EOF, "<<EOF>>", lastLine, lastCol);

        } else if (next.tipo == TokenTypes.ERROR) {
             // Si el lexer encontró un error léxico (carácter no reconocido), lo reportamos.
             // Pasa el Yytoken de error. Reporta como error sintáctico/léxico (false).
             reportError("Error léxico: Caracter '" + next.valor + "' inesperado.", next, false);
             // Estrategia de recuperación simple para errores léxicos: reporta y lee el *siguiente* token real.
             // Esto evita que el parser se quede atascado en un token léxico inválido.
             lookahead = next; // Asigna el Yytoken de error momentáneamente (útil para el reporte)
             nextToken(); // Lee el siguiente token *real* para continuar el análisis sintáctico.
        } else {
             // Es un token normal y válido. Asigna el Yytoken leído al 'lookahead'.
             lookahead = next;
        }

        // Opcional: Imprimir el token leído para depuración.
        // System.out.println("Leído: " + lookahead);
    }

    // --- Método match() CORREGIDO con recuperación de errores ---
    // Intenta "consumir" (hacer coincidir) el token actual (lookahead) con un tipo esperado.
    // Si coincide, avanza al siguiente token. Si no coincide, reporta un error y salta el token actual.
    private void match(int expectedType) throws Exception {
        if (lookahead.tipo == expectedType) { // Si el tipo del token actual coincide con el esperado
            nextToken(); // Match exitoso: Consume el token y lee el siguiente.
        } else {
            // Match fallido. Reporta el error.
            // Usamos la posición del lookahead (el token encontrado inesperadamente) para el reporte.
            if (expectedType == TokenTypes.PUNTO_COMA) {
                 // Mensaje específico para cuando se esperaba un PUNTO_COMA pero se encontró otra cosa.
                 // Reporta en la línea del token encontrado (que suele ser la siguiente a donde faltaba el ';').
                 reportError("Punto y coma ';' esperado al final de la sentencia anterior. Encontrado '" + lookahead.valor + "' ('" + getTokenTypeString(lookahead.tipo) + "').", lookahead, false); // false indica error sintáctico.
            } else {
                 // Mensaje general para cualquier otro tipo de token inesperado.
                 reportError("Token inesperado. Se esperaba '" + getTokenTypeString(expectedType) + "' pero se encontró '" + lookahead.valor + "' ('" + getTokenTypeString(lookahead.tipo) + "').", lookahead, false); // false indica error sintáctico.
            }

            // --- RECUPERACIÓN DE ERRORES BÁSICA (Modo Pánico) ---
            // Después de reportar un error en un match, AVANZA el lookahead.
            // Esto es CRUCIAL para evitar bucles infinitos si el parser se atasca.
            // Simplemente saltamos el token actual que no coincidió.
            // Asegúrate de no intentar leer más allá del final del archivo.
            if (lookahead.tipo != TokenTypes.EOF) {
                 nextToken(); // Lee y avanza al siguiente token.
            }
            // --- Fin Recuperación ---
        }
    }

     // Método auxiliar para obtener el nombre String de un tipo de token a partir de su constante int.
     // Usado para mensajes de error y la tabla de tokens en la GUI.
     private String getTokenTypeString(int tipo) {
         switch (tipo) {
             case TokenTypes.EOF: return "EOF";
             case TokenTypes.ERROR: return "ERROR";
             case TokenTypes.MOVER: return "MOVER"; // Si aún usas
             case TokenTypes.GIRAR: return "GIRAR"; // Si aún usas
             case TokenTypes.NUMBER: return "NUMBER";
             case TokenTypes.PUNTO_COMA: return "PUNTO_COMA";
             case TokenTypes.IDENTIFIER: return "IDENTIFIER";
             case TokenTypes.ROBOT_KW: return "ROBOT_KW"; // Si aún usas

             // Casos para los nuevos tipos de token de la gramática expandida.
             case TokenTypes.ROBOT_TYPE: return "Robot (Type)"; // Palabra clave "Robot" (con R mayúscula)
             case TokenTypes.PUNTO: return "PUNTO"; // Operador '.'
             case TokenTypes.ASIGNACION: return "ASIGNACION"; // Operador '='
             case TokenTypes.PAREN_ABRE: return "PAREN_ABRE"; // Símbolo '('
             case TokenTypes.PAREN_CIERRA: return "PAREN_CIERRA"; // Símbolo ')'
             case TokenTypes.INICIAR_KW: return "iniciar (Method)"; // Palabra clave "iniciar"
             case TokenTypes.BASE_KW: return "base (Property)"; // Palabra clave "base"
             case TokenTypes.GARRA_KW: return "garra (Property)"; // Palabra clave "garra"
             case TokenTypes.DETENER_KW: return "detener (Method)"; // Palabra clave "detener"
             case TokenTypes.ABRIR_GARRA_KW: return "abrirGarra (Method)"; // Palabra clave "abrirGarra"
             case TokenTypes.CERRAR_GARRA_KW: return "cerrarGarra (Method)"; // Palabra clave "cerrarGarra"


             // Agrega casos aquí para cualquier otro tipo de token que añadas en TokenTypes.
             default: return "UNKNOWN(" + tipo + ")"; // Devuelve un nombre genérico si el tipo es desconocido.
         }
     }

    // --- Método reportError() ---
    // Reporta un error. Recibe el mensaje, el token donde ocurrió el error (para posición)
    // y un booleano para indicar si es un error semántico o sintáctico.
    // Formatea el mensaje para que la GUI pueda extraer la línea.
    private void reportError(String message, Yytoken token, boolean isSemantic) { // Recibe un Yytoken
        // Determina el prefijo del mensaje (Error semántico o Error sintáctico).
        String errorType = isSemantic ? "Error semántico" : "Error sintáctico";

        // Construye el mensaje de error, incluyendo la posición del token (1-basada).
        errores.append(errorType)
               .append(" en línea ").append(token.linea + 1) // Suma 1 a la línea 0-basada.
               .append(", columna ").append(token.columna + 1) // Suma 1 a la columna 0-basada.
               .append(": ").append(message).append("\n"); // Añade el mensaje y un salto de línea.
    }


    // ---- Implementación de las Reglas de la Gramática (Métodos de Parsing por Descenso Recursivo) ----
    // Cada método parse...() intenta reconocer una estructura gramatical específica (un no-terminal).
    // Estos métodos operan sobre el 'lookahead' (Yytoken) y llaman a 'match()' (que ahora incluye recuperación) o a otros métodos 'parse...()'.


    // Regla de inicio: Program -> { Statement ; }* [Statement] <<EOF>>
    // Un programa es una secuencia de cero o más sentencias, cada una (excepto posiblemente la última)
    // seguida por un punto y coma. Termina con el fin de archivo.
    private void parseProgram() throws Exception {
         // Un programa vacío (solo EOF) es válido. El bucle no se ejecutará si el primer token es EOF.
         while(lookahead.tipo != TokenTypes.EOF) {
              // Espera una sentencia (Declaración, Asignación, Llamada a Método, etc.)
              parseStatement(); // parseStatement llamará a otros métodos que llaman a match. match ahora recupera.

              // Después de cada sentencia, esperamos un punto y coma como separador.
              // match ahora salta el token si no es un punto y coma y reporta el error.
              match(TokenTypes.PUNTO_COMA);

              // Si después de consumir el punto y coma (o saltar el token si faltaba)
              // el siguiente token es EOF, salimos del bucle porque el programa ha terminado.
              if (lookahead.tipo == TokenTypes.EOF) {
                  break;
              }

              // Si el lookahead no es EOF, el bucle continúa esperando la próxima sentencia.
              // La recuperación en match() debería haber avanzado el lookahead más allá de un token incorrecto
              // si se encontraron errores.
         }
         // Cuando el bucle termina, el lookahead debe ser EOF.
    }


    // Regla: Statement -> RobotDeclaration | MemberStatement
    // Una sentencia puede ser una declaración de robot O una sentencia que opera sobre un miembro.
    // La elección se basa en el primer token de la sentencia.
    private void parseStatement() throws Exception {
        if (lookahead.tipo == TokenTypes.ROBOT_TYPE) { // Si empieza con la palabra clave "Robot"
            parseRobotDeclaration(); // Es una declaración de robot.
        } else if (lookahead.tipo == TokenTypes.IDENTIFIER) { // Si empieza con un identificador (nombre de robot)
            parseMemberStatement(); // Es una sentencia que opera sobre un miembro (ej: r1.iniciar).
        }
        // Opcional: Si mantienes comandos antiguos como MOVER 10; y pueden ser sentencias de nivel superior.
        // else if (lookahead.tipo == TokenTypes.MOVER || lookahead.tipo == TokenTypes.GIRAR) {
        //     parseCommand(); // Llama al método para parsear MOVER/GIRAR (si lo tienes).
        // }
         else {
            // Si el lookahead no coincide con el inicio de ninguna sentencia válida.
            // Reporta el error usando la posición del token actual.
            reportError("Se esperaba una declaración (Robot), un identificador (nombre de robot), o un comando válido.", lookahead, false); // false indica error sintáctico.
            // La recuperación en match() no se llama aquí, ya que no hubo un match fallido directo.
            // Si el token actual no es EOF y no es un inicio de sentencia válido, puede ser necesario avanzar manualmente
            // para evitar quedarse atascado si el parser no reconoce el inicio de la sentencia.
            // if (lookahead.tipo != TokenTypes.EOF) nextToken(); // Recuperación adicional si no se reconoce el inicio.
        }
        // parseStatement NO consume el punto y coma; eso lo hace el método padre (parseProgram).
    }


    // Regla: RobotDeclaration -> ROBOT_TYPE Identifier
    // Parsear la sintaxis Y AÑADIR el nombre a la tabla de símbolos.
    private void parseRobotDeclaration() throws Exception {
        // Ya sabemos que lookahead es ROBOT_TYPE al entrar aquí (por parseStatement).
        match(TokenTypes.ROBOT_TYPE);   // Consume "Robot". match ahora recupera si el siguiente no es Identifier.

        // El siguiente token DEBE ser el identificador (el nombre del robot).
        // match ahora salta si no es un Identifier y reporta el error.
        if (lookahead.tipo == TokenTypes.IDENTIFIER) { // Verifica el tipo *antes* de asumir que es el identificador.
             Yytoken robotNameToken = lookahead; // Captura el token del nombre del robot.
             match(TokenTypes.IDENTIFIER); // Consume el identificador (lookahead avanza).

             // --- Análisis Semántico: Registrar el nombre en la tabla de símbolos ---
             String robotName = robotNameToken.valor; // Obtiene el nombre como String.
             if (declaredRobots.contains(robotName)) {
                 // Error semántico: El robot ya fue declarado.
                 reportError("El robot '" + robotName + "' ya ha sido declarado.", robotNameToken, true); // true indica error semántico.
             } else {
                 // Es un nuevo robot. Añade su nombre al conjunto de robots declarados.
                 declaredRobots.add(robotName);
                 // Opcional: System.out.println("DEBUG: Robot declarado: " + robotName);
             }
        } else {
            // Si el match(TokenTypes.IDENTIFIER) falló, ya se reportó un error en match().
            // Este 'else' captura el caso si el token después de 'Robot' no era un IDENTIFIER
            // y match() ya avanzó el lookahead.
            // Si quieres un mensaje de error más específico AQUI, podrías añadirlo.
            // reportError("Nombre de robot esperado después de 'Robot'.", lookahead, false); // Ya se reportó algo en match().
        }

        // El punto y coma se consume en parseProgram.
    }


    // Regla: MemberStatement -> Identifier PUNTO (AssignmentTail | MethodCallTail)
    // Implementación: Verificar que el IDENTIFIER inicial esté declarado antes de proceder
    // y luego parsear la parte del miembro.
    private void parseMemberStatement() throws Exception {
        // Al entrar aquí, 'lookahead' es un IDENTIFIER (por cómo parseStatement nos llama).
        Yytoken robotIdToken = lookahead; // Captura el token del identificador (ej: "miRobotabrirGarra" o "miRobot").
        String robotNameUsed = robotIdToken.valor; // Obtiene el nombre usado.

        // --- Análisis Semántico: Verificar si el robot ha sido declarado ---
        // Esta verificación sigue siendo necesaria, ya que "miRobotabrirGarra" como identificador completo
        // probablemente no ha sido declarado como robot.
        if (!declaredRobots.contains(robotNameUsed)) {
            reportError("El robot '" + robotNameUsed + "' no ha sido declarado.", robotIdToken, true); // true indica error semántico.
            // Continuamos el análisis sintáctico para encontrar más errores si los hay.
        }

        // Consume el identificador que inició esta sentencia de miembro.
        match(TokenTypes.IDENTIFIER); // lookahead avanza al token después del identificador. match ahora salta si falla (si no era un IDENTIFIER).

        // --- Verificación ESPECÍFICA de la FALTA del PUNTO '.' ---
        // Después de consumir el IDENTIFIER (ej: "miRobot" o "miRobotabrirGarra"),
        // esperamos que el siguiente token sea un PUNTO.
        if (lookahead.tipo != TokenTypes.PUNTO) {
             // ¡Error! Se esperaba el punto '.' aquí.
             // Reporta un error sintáctico específico para el punto faltante.
             // Usamos la posición del token IDENTIFIER (robotIdToken) para el reporte,
             // ya que el punto debería haber estado justo después.
             reportError("Operador '.' esperado después del nombre del robot '" + robotIdToken.valor + "'.", robotIdToken, false); // false indica error sintáctico.

             // --- Recuperación de Errores para este caso ---
             // Como sabemos que la estructura de la sentencia de miembro está rota aquí,
             // intentamos saltar tokens hasta encontrar un posible fin de sentencia (;)
             // o el inicio de una nueva sentencia (Robot, Identificador, EOF).
             // Esto evita una cascada de errores al intentar parsear el resto de la línea incorrectamente.
             while(lookahead.tipo != TokenTypes.EOF && lookahead.tipo != TokenTypes.PUNTO_COMA &&
                   lookahead.tipo != TokenTypes.ROBOT_TYPE && lookahead.tipo != TokenTypes.IDENTIFIER) {
                 nextToken(); // Salta el token actual si no es un posible punto de sincronización.
             }

             // Después de la recuperación, salimos de este método parseMemberStatement.
             // El método padre (parseProgram) esperará el ';' (o lo saltará si falta).
             return; // Sale del método después de reportar y recuperarse.
        }
        // --- Fin Verificación ESPECÍFICA de la FALTA del PUNTO ---


        // Si el lookahead SÍ es un PUNTO, lo consumimos y continuamos parseando el miembro.
        match(TokenTypes.PUNTO); // Consume '.' (lookahead avanza al token después del punto). match ahora salta si falla.

        // Ahora, lo que viene después del punto determinará si es una asignación o una llamada a método.
        // El lookahead es ahora el nombre del miembro (base, garra, iniciar, etc.) o un token inesperado.
        // Los métodos parseAssignmentTail y parseMethodCallTail también llaman a match, que ahora recupera.
        if (lookahead.tipo == TokenTypes.BASE_KW || lookahead.tipo == TokenTypes.GARRA_KW) {
            // Si el nombre del miembro es 'base' o 'garra', esperamos una asignación.
            parseAssignmentTail(robotIdToken); // Pasa el token del ID del robot para posibles verificaciones semánticas posteriores.
        } else if (lookahead.tipo == TokenTypes.INICIAR_KW || lookahead.tipo == TokenTypes.DETENER_KW ||
                   lookahead.tipo == TokenTypes.ABRIR_GARRA_KW || lookahead.tipo == TokenTypes.CERRAR_GARRA_KW) {
            // Si el nombre del miembro es 'iniciar', 'detener', etc., esperamos una llamada a método.
            parseMethodCallTail(robotIdToken); // Pasa el token del ID del robot.
        }
         else {
            // Error sintáctico: Se esperaba un nombre de miembro/método válido después de '.'
            reportError("Nombre de miembro o método esperado (base, garra, iniciar, detener, etc.) después de '.'", lookahead, false); // false indica error sintáctico.
            // La recuperación en match() no se llamó aquí si lookahead no coincide.
            // Podemos añadir una recuperación adicional si no es un token de sincronización para evitar quedarse atascado.
            // if (lookahead.tipo != TokenTypes.EOF && lookahead.tipo != TokenTypes.PUNTO_COMA && lookahead.tipo != TokenTypes.ROBOT_TYPE && lookahead.tipo != TokenTypes.IDENTIFIER) nextToken();
        }
        // El punto y coma que termina la sentencia (MemberStatement) se consume en parseProgram.
    }


    // Regla: AssignmentTail -> (BASE_KW | GARRA_KW) ASIGNACION NUMBER
    // Parser la parte de asignación después de haber consumido el Identifier y el PUNTO.
    private void parseAssignmentTail(Yytoken robotIdToken) throws Exception { // Recibe el token del ID del robot.
        // Al entrar aquí, lookahead ya debería ser BASE_KW o GARRA_KW (ver parseMemberStatement).
        if (lookahead.tipo == TokenTypes.BASE_KW || lookahead.tipo == TokenTypes.GARRA_KW) {
             Yytoken propertyNameToken = lookahead; // Captura el token del nombre de la propiedad.
             match(lookahead.tipo); // Consume el nombre de la propiedad (match ahora salta si falla).

             match(TokenTypes.ASIGNACION); // Espera y consume "=" (match ahora salta si falla).
             match(TokenTypes.NUMBER);     // Espera y consume el número (match ahora salta si falla).

             // Aquí iría más análisis semántico (usando robotIdToken y propertyNameToken):
             // 1. Verificar si 'propertyNameToken.valor' es una propiedad válida para el tipo de robot 'robotIdToken.valor'.
             // 2. Verificar si el valor (el número consumido) es compatible con esa propiedad.
        } else {
             // Error sintáctico: Esto no debería ocurrir si parseMemberStatement llamó correctamente.
             reportError("Nombre de propiedad esperado (base o garra) después de '.'", lookahead, false); // false indica error sintáctico.
             // La recuperación en match() no se llama aquí. Si el lookahead no coincide, match() fue llamado en MemberStatement y ya reportó/saltó.
        }
        // El punto y coma se consume en parseProgram.
    }


    // Regla: MethodCallTail -> (INICIAR_KW | DETENER_KW | ABRIR_GARRA_KW | CERRAR_GARRA_KW) PAREN_ABRE PAREN_CIERRA
    // Parser la parte de llamada a método después de haber consumido el Identifier y el PUNTO.
    private void parseMethodCallTail(Yytoken robotIdToken) throws Exception { // Recibe el token del ID del robot.
         // Al entrar aquí, lookahead ya debería ser INICIAR_KW, DETENER_KW, etc.
         if (lookahead.tipo == TokenTypes.INICIAR_KW || lookahead.tipo == TokenTypes.DETENER_KW ||
             lookahead.tipo == TokenTypes.ABRIR_GARRA_KW || lookahead.tipo == TokenTypes.CERRAR_GARRA_KW) {

              Yytoken methodNameToken = lookahead; // Captura el token del nombre del método.
              match(lookahead.tipo); // Consume el nombre del método (match ahora salta si falla).

              match(TokenTypes.PAREN_ABRE);  // Espera y consume "(" (match ahora salta si falla).
              // Aquí iría el parsing de argumentos si el método tuviera.
              match(TokenTypes.PAREN_CIERRA); // Espera y consume ")" (match ahora salta si falla).

              // Aquí iría más análisis semántico (usando robotIdToken y methodNameToken):
              // 1. Verificar si 'methodNameToken.valor' es un método válido para el tipo de robot 'robotIdToken.valor'.
              // 2. Verificar si los argumentos proporcionados son correctos para el método.
         } else {
              // Error sintáctico: Esto no debería ocurrir si parseMemberStatement llamó correctamente.
              reportError("Nombre de método esperado (iniciar, detener, abrirGarra, cerrarGarra) después de '.'", lookahead, false); // false indica error sintáctico.
         }
        // El punto y coma se consume en parseProgram.
    }

    // Opcional: Método para parsear comandos antiguos si aún son sentencias válidas de nivel superior.
    // private void parseCommand() throws Exception { ... }

    // Nota: El método parseCommandList ya no se usa si parseProgram llama directamente a parseStatement.


    // Agrega aquí métodos parse...() adicionales si tu lenguaje tiene más estructuras.
}