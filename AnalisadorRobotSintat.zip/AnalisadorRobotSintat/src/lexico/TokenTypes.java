// src/lexico/TokenTypes.java
package lexico;

public interface TokenTypes {
    int EOF = 0;
    int ERROR = 1;
    int MOVER = 2;        // Si aún usas este
    int GIRAR = 3;        // Si aún usas este
    int NUMBER = 4;
    int PUNTO_COMA = 5;
    int IDENTIFIER = 6;
    int ROBOT_KW = 7;     // Palabra clave "ROBOT" (si la mantienes)

    // *** NUEVAS CONSTANTES BASADAS EN LA IMAGEN ***
    int ROBOT_TYPE = 8;   // Palabra clave "Robot" (con R mayúscula)
    int PUNTO = 9;        // Operador '.'
    int ASIGNACION = 10;  // Operador '='
    int PAREN_ABRE = 11;  // Símbolo '('
    int PAREN_CIERRA = 12; // Símbolo ')'

    // Palabras clave que parecen nombres de miembros/métodos en la imagen
    int INICIAR_KW = 13; // Palabra clave "iniciar"
    int BASE_KW = 14;    // Palabra clave "base"
    int GARRA_KW = 15;   // Palabra clave "garra"
    int DETENER_KW = 16; // Palabra clave "detener"
    int ABRIR_GARRA_KW = 17; // Palabra clave "abrirGarra"
    int CERRAR_GARRA_KW = 18; // Palabra clave "cerrarGarra"


    // Asegúrate de que todos los números sean únicos.
    // Puedes renombrar ROBOT_KW (7) a algo como ROBOT_DECLARATION_KW si usas ROBOT_TYPE (8)
    // para la declaración misma ("Robot r1;").
    // O simplemente usa ROBOT_TYPE para la declaración y elimina ROBOT_KW si solo usas "Robot".
    // Usaremos ROBOT_TYPE para "Robot" en la declaración.
}