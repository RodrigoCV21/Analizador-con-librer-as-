// src/lexico/Token.java
package lexico;

public class Token {
    public int tipo; // Usaremos una constante int para el tipo (de TokenTypes)
    public String valor;
    public int linea;    // Línea donde se encuentra el token (0-basada)
    public int columna;  // Columna donde comienza el token (0-basada)

    // Este es el UNICO constructor que debe tomar (int, String, int, int)
    public Token(int tipo, String valor, int linea, int columna) {
        this.tipo = tipo;
        this.valor = valor;
        this.linea = linea;
        this.columna = columna;
    }

    // Métodos getter (opcionales)
    public int getTipo() { return tipo; }
    public String getValor() { return valor; }
    public int getLinea() { return linea; }
    public int getColumna() { return columna; }

    @Override
    public String toString() {
        return "Token{" +
               "tipo=" + tipo +
               ", valor='" + valor + '\'' +
               ", linea=" + linea +
               ", columna=" + columna +
               '}';
    }
}