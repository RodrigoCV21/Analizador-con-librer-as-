// src/lexico/Yytoken.java
package lexico;

// Clase que representa un token reconocido por el lexer.
// Contiene el tipo, valor, línea y columna del token.
public class Yytoken {
    public int tipo;      // El tipo de token (usando las constantes de TokenTypes)
    public String valor;  // El valor o texto del token (ej: "100" para NUMBER, "miRobot" para IDENTIFIER)
    public int linea;     // La línea donde comienza el token (0-basada, de yyline)
    public int columna;   // La columna donde comienza el token (0-basada, de yycolumn)

    // Constructor para crear un nuevo objeto token.
    public Yytoken(int tipo, String valor, int linea, int columna) {
        this.tipo = tipo;
        this.valor = valor;
        this.linea = linea;
        this.columna = columna;
    }

    // Métodos getter (opcionales, pero buena práctica para acceder a los campos)
    public int getTipo() { return tipo; }
    public String getValor() { return valor; }
    public int getLinea() { return linea; }
    public int getColumna() { return columna; }

    @Override
    public String toString() {
        // Representación del token como cadena (útil para depuración y la tabla de tokens)
        // Puedes mapear 'tipo' a su nombre String aquí si quieres, o usar el helper en la GUI.
        return "Yytoken{" +
               "tipo=" + tipo + // Podrías usar getTokenTypeString(tipo) si lo haces estático aquí
               ", valor='" + valor + '\'' +
               ", linea=" + (linea + 1) + // Mostrar línea 1-basada
               ", columna=" + (columna + 1) + // Mostrar columna 1-basada
               '}';
    }

    // Opcional: Un método helper para obtener el nombre String del tipo de token
    // Podrías copiar el switch de TokenTypes aquí o seguir usando el helper en la GUI y Parser.
    // static String getTokenTypeString(int tipo) { ... }
}